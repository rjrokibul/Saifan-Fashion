import React from 'react'
import ReactDOM from 'react-dom/client'
import SaifanFashionSite from './saifanFashionSite'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <SaifanFashionSite />
  </React.StrictMode>
)