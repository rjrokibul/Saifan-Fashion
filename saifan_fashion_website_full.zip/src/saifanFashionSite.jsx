import React from "react";
import { motion } from "framer-motion";
import { Phone, MapPin, Facebook, Instagram, Send, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

const BRAND = "Saifan Fashion";
const TAGLINE = "সবার জন্য মানসম্মত গার্মেন্টস";
const WHATSAPP_LINK = "https://wa.me/8801759797642";
const PHONE = "+880 1759-797642";
const ADDRESS = "Muktinagar, Narayanganj, Shiddirgonj, Narayanganj, Bangladesh";

const LOGO_URL = "/saifan_fashion_logo.png"; // আপনার PNG লোগো public ফোল্ডারে রাখতে হবে

const products = [
  { id: 1, name: "Short Sleeve T-Shirt", price: 650, desc: "Comfortable cotton short sleeve T-shirt.", img: "https://images.unsplash.com/photo-1520975605360-6c5a7a1a5a9b?q=80&w=1200&auto=format&fit=crop", tag: "New" },
  { id: 2, name: "Long Sleeve T-Shirt", price: 750, desc: "Trendy and soft fabric, perfect for casual wear.", img: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=1200&auto=format&fit=crop", tag: "Best-seller" },
  { id: 3, name: "Polo Shirts", price: 990, desc: "Classic polo shirts with premium quality fabric.", img: "https://images.unsplash.com/photo-1618354691418-1bcd98a3e1b1?q=80&w=1200&auto=format&fit=crop", tag: "Hot" },
  { id: 4, name: "Trousers", price: 1190, desc: "Slim fit trousers for office and casual wear.", img: "https://images.unsplash.com/photo-1516822003754-cca485356ecb?q=80&w=1200&auto=format&fit=crop", tag: "Featured" },
  { id: 5, name: "Joggers & Track Pants", price: 890, desc: "Comfortable joggers and track pants for daily wear.", img: "https://images.unsplash.com/photo-1542060748-10c28b62716f?q=80&w=1200&auto=format&fit=crop", tag: "New" },
  { id: 6, name: "Custom Logo/Print Garments", price: 0, desc: "Custom design, logo printing and bulk orders available.", img: "https://images.unsplash.com/photo-1520975922284-9e0ce8273ca1?q=80&w=1200&auto=format&fit=crop", tag: "Custom" }
];

const Section = ({ id, title, subtitle, children }) => (
  <section id={id} className="py-16 lg:py-20">
    <div className="max-w-6xl mx-auto px-4">
      <motion.div initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }} className="mb-10">
        <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-blue-900">{title}</h2>
        {subtitle && (<p className="text-sm md:text-base text-gray-600 mt-2">{subtitle}</p>)}
      </motion.div>
      {children}
    </div>
  </section>
);

export default function SaifanFashionSite() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-blue-50 to-white text-slate-900">
      {/* HEADER */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/80 border-b">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src={LOGO_URL} alt="Saifan Fashion Logo" className="h-10 w-auto" />
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#products" className="hover:opacity-80">Products</a>
            <a href="#about" className="hover:opacity-80">About</a>
            <a href="#contact" className="hover:opacity-80">Contact</a>
          </nav>
          <div className="flex items-center gap-2">
            <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer">
              <Button className="rounded-2xl bg-blue-600 hover:bg-blue-700 text-white">Order on WhatsApp</Button>
            </a>
          </div>
        </div>
      </header>
      {/* HERO */}
      {/* ... rest of code ... */}
    </div>
  );
}